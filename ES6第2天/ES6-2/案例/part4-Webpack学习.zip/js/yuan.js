function mianji(r){
	return 3.14 * r * r;
}

exports.mianji = mianji;