function mianji(a,b){
	return a * b;
}

exports.mianji = mianji;