export const mianji = function(a,b){
	return a * b;
}

export const zhouchang = function(a , b){
	return 2 * (a + b);
}