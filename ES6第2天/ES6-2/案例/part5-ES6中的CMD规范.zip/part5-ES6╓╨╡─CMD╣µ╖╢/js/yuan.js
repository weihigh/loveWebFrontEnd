export const mianji = function(r){
	return 3.14 * r * r;
}

export const zhouchang = function(r){
	return 6.28 * r;
}

