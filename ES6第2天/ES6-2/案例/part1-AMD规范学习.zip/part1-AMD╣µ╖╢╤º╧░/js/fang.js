define(function(){
	function mianji(a,b){
		return a * b;
	}

	return {
		mianji
	}
});