define(function(){
	function mianji(r){
		return 3.14 * r * r;
	}

	return {
		mianji  //k、v相同，省略v
	}
});