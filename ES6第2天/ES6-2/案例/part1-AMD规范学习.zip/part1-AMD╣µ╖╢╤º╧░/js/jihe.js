define(["fang","circle"],function(fang,circle){
	return {
		fang,
		circle
	}
});