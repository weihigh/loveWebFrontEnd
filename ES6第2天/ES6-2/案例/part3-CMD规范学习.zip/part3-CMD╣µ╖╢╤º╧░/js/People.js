define(function(require,exports,module){
	function People(){

	}

	module.exports = People;
});