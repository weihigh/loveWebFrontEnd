define(function(require,exports,module){
	function mianji(r){
		return r * r * 3.14;
	}

	exports.mianji = mianji;
});