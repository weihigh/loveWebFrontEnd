for(var i = 0 ; i < 10 ; i++){
	console.log(haha(i));
}

function haha(a){
	return a * 3;
}