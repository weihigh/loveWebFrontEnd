var jihe = require("jihe");

console.log(jihe.yuan.mianji(10));
console.log(jihe.juxing.zhouchang(10,19));